import type { OfferWithBook } from '@/types/entities/OfferWithBook.d';
import type { ListResponse } from '@/types/entities/ListResponse.d';
import { OfferType, OfferStatus } from '@/types/entities/Offer.d';
import { BookCondition } from '@/types/entities/Book.d';

// Mock sellers/owners data
export const mockSellers = [
  { id: 1, name: 'Alex Johnson', avatar: '' },
  { id: 2, name: 'Maria Garcia', avatar: '' },
  { id: 3, name: 'Jane Walker', avatar: '' },
  { id: 4, name: 'John Smith', avatar: '' },
  { id: 5, name: 'Emma Wilson', avatar: '' },
  { id: 6, name: 'Michael Brown', avatar: '' },
  { id: 7, name: 'Sarah Davis', avatar: '' },
  { id: 8, name: 'David Miller', avatar: '' },
  { id: 9, name: 'Lisa Anderson', avatar: '' },
  { id: 10, name: 'Robert Taylor', avatar: '' },
  { id: 11, name: 'Anna Thompson', avatar: '' },
  { id: 12, name: 'Chris Martinez', avatar: '' },
  { id: 13, name: 'Sophie Lee', avatar: '' },
];

// Mock book offers data
export const mockOffers: OfferWithBook[] = [
  {
    id: '1',
    price: 300,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Great condition sci-fi book',
    previewImage: '',
    sellerId: '1',
    book: {
      id: '1',
      title: 'Babel',
      authors: ['Rebecca Kuang'],
      genres: ['sci-fi', 'fantasy'],
      condition: BookCondition.NEW,
      description:
        'A dark academic fantasy novel about the power of translation and colonialism.',
      images: [],
      isbn: '978-0-06-303752-8',
      yearOfRelease: 2022,
    },
    seller: {
      id: 1,
      name: 'Alex Johnson',
      avatar: '',
    },
  },
  {
    id: '2',
    price: 250,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Excellent sci-fi book',
    previewImage: '',
    sellerId: '2',
    book: {
      id: '2',
      title: 'Babel',
      authors: ['Rebecca Kuang'],
      genres: ['sci-fi', 'fantasy'],
      condition: BookCondition.NEW,
      description:
        'A dark academic fantasy novel about the power of translation and colonialism.',
      images: [],
      isbn: '978-0-06-303752-8',
      yearOfRelease: 2022,
    },
    seller: {
      id: 2,
      name: 'Maria Garcia',
      avatar: '',
    },
  },
  {
    id: '3',
    price: 280,
    type: OfferType.EXCHANGE,
    status: OfferStatus.OPEN,
    description: 'Looking to exchange this amazing book',
    previewImage: '',
    sellerId: '3',
    book: {
      id: '3',
      title: 'Babel',
      authors: ['Rebecca Kuang'],
      genres: ['sci-fi', 'fantasy'],
      condition: BookCondition.NEW,
      description:
        'A dark academic fantasy novel about the power of translation and colonialism.',
      images: [],
      isbn: '978-0-06-303752-8',
      yearOfRelease: 2022,
    },
    seller: {
      id: 3,
      name: 'Jane Walker',
      avatar: '',
    },
  },
  {
    id: '4',
    price: 200,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Classic science fiction masterpiece',
    previewImage: '',
    sellerId: '4',
    book: {
      id: '4',
      title: 'Dune',
      authors: ['Frank Herbert'],
      genres: ['sci-fi'],
      condition: BookCondition.USED,
      description:
        'Epic science fiction novel set on the desert planet Arrakis.',
      images: [],
      isbn: '978-0-441-17271-9',
      yearOfRelease: 1965,
    },
    seller: {
      id: 4,
      name: 'John Smith',
      avatar: '',
    },
  },
  {
    id: '5',
    price: 350,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Amazing survival story',
    previewImage: '',
    sellerId: '5',
    book: {
      id: '5',
      title: 'The Martian',
      authors: ['Andy Weir'],
      genres: ['sci-fi'],
      condition: BookCondition.NEW,
      description: 'A thrilling story of survival on Mars.',
      images: [],
      isbn: '978-0-553-41802-6',
      yearOfRelease: 2011,
    },
    seller: {
      id: 5,
      name: 'Sarah Davis',
      avatar: '',
    },
  },
  {
    id: '6',
    price: 180,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Classic Foundation series',
    previewImage: '',
    sellerId: '6',
    book: {
      id: '6',
      title: 'Foundation',
      authors: ['Isaac Asimov'],
      genres: ['sci-fi'],
      condition: BookCondition.USED,
      description:
        'Classic science fiction about psychohistory and the fall of empire.',
      images: [],
      isbn: '978-0-553-29335-0',
      yearOfRelease: 1951,
    },
    seller: {
      id: 6,
      name: 'Robert Brown',
      avatar: '',
    },
  },
  {
    id: '7',
    price: 320,
    type: OfferType.EXCHANGE,
    status: OfferStatus.OPEN,
    description: 'Cyberpunk classic for trade',
    previewImage: '',
    sellerId: '7',
    book: {
      id: '7',
      title: 'Neuromancer',
      authors: ['William Gibson'],
      genres: ['sci-fi', 'cyberpunk'],
      condition: BookCondition.NEW,
      description:
        'Groundbreaking cyberpunk novel about cyberspace and artificial intelligence.',
      images: [],
      isbn: '978-0-441-56956-9',
      yearOfRelease: 1984,
    },
    seller: {
      id: 7,
      name: 'David Lee',
      avatar: '',
    },
  },
  {
    id: '8',
    price: 275,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Ursula K. Le Guin masterpiece',
    previewImage: '',
    sellerId: '8',
    book: {
      id: '8',
      title: 'The Left Hand of Darkness',
      authors: ['Ursula K. Le Guin'],
      genres: ['sci-fi'],
      condition: BookCondition.NEW,
      description: 'Influential science fiction exploring gender and society.',
      images: [],
      isbn: '978-0-441-47812-5',
      yearOfRelease: 1969,
    },
    seller: {
      id: 8,
      name: 'Michael Wilson',
      avatar: '',
    },
  },
  {
    id: '9',
    price: 190,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Space military fiction',
    previewImage: '',
    sellerId: '9',
    book: {
      id: '9',
      title: "Ender's Game",
      authors: ['Orson Scott Card'],
      genres: ['sci-fi'],
      condition: BookCondition.USED,
      description:
        'Military science fiction about a child prodigy in space war.',
      images: [],
      isbn: '978-0-312-93208-2',
      yearOfRelease: 1985,
    },
    seller: {
      id: 9,
      name: 'Lisa Martinez',
      avatar: '',
    },
  },
  {
    id: '10',
    price: 310,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'H.G. Wells classic',
    previewImage: '',
    sellerId: '10',
    book: {
      id: '10',
      title: 'The Time Machine',
      authors: ['H.G. Wells'],
      genres: ['sci-fi', 'classic'],
      condition: BookCondition.NEW,
      description:
        'Classic time travel story by the father of science fiction.',
      images: [],
      isbn: '978-0-486-28472-1',
      yearOfRelease: 1895,
    },
    seller: {
      id: 10,
      name: 'Lisa Martinez',
      avatar: '',
    },
  },
];

// Mock romantic books
export const mockRomanticOffers: OfferWithBook[] = [
  {
    id: '11',
    price: 280,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Classic romance novel',
    previewImage: '',
    sellerId: '11',
    book: {
      id: '11',
      title: 'Pride and Prejudice',
      authors: ['Jane Austen'],
      genres: ['romantic', 'classic'],
      condition: BookCondition.NEW,
      description:
        'Classic romance novel about Elizabeth Bennet and Mr. Darcy.',
      images: [],
      isbn: '978-0-14-143951-8',
      yearOfRelease: 1813,
    },
    seller: {
      id: 11,
      name: 'Lisa Martinez',
      avatar: '',
    },
  },
  {
    id: '12',
    price: 250,
    type: OfferType.SELL,
    status: OfferStatus.OPEN,
    description: 'Heart-wrenching romance',
    previewImage: '',
    sellerId: '12',
    book: {
      id: '12',
      title: 'The Notebook',
      authors: ['Nicholas Sparks'],
      genres: ['romantic', 'contemporary'],
      condition: BookCondition.USED,
      description: 'Heart-wrenching love story spanning decades.',
      images: [],
      isbn: '978-0-446-60523-4',
      yearOfRelease: 1996,
    },
    seller: {
      id: 12,
      name: 'James Wilson',
      avatar: '',
    },
  },
  {
    id: '13',
    price: 300,
    type: OfferType.EXCHANGE,
    status: OfferStatus.OPEN,
    description: 'Emotional contemporary romance',
    previewImage: '',
    sellerId: '13',
    book: {
      id: '13',
      title: 'Me Before You',
      authors: ['Jojo Moyes'],
      genres: ['romantic', 'contemporary'],
      condition: BookCondition.NEW,
      description:
        'Emotional love story that will change your perspective on life.',
      images: [],
      isbn: '978-0-14-312454-1',
      yearOfRelease: 2012,
    },
    seller: {
      id: 13,
      name: 'Lisa Martinez',
      avatar: '',
    },
  },
];

// Function to create mock API response
export function createMockResponse<T>(
  content: T[],
  totalElements?: number
): ListResponse<T> {
  return {
    content,
    totalElements: totalElements || content.length,
    totalPages: Math.ceil((totalElements || content.length) / 20),
    size: 20,
    number: 0,
    numberOfElements: content.length,
    pageable: {
      offset: 0,
      pageNumber: 0,
      pageSize: 20,
      pages: false,
      sort: {
        empty: true,
        sorted: false,
        unsorted: true,
      },
    },
    sort: {
      empty: true,
      sorted: false,
      unsorted: true,
    },
  };
}

// Get all available genres from the mock data
export function getAllGenres(): string[] {
  const allOffers = [...mockOffers, ...mockRomanticOffers];
  const genresSet = new Set<string>();

  allOffers.forEach((offer) => {
    offer.book.genres.forEach((genre) => genresSet.add(genre));
  });

  return Array.from(genresSet).sort();
}

// Filter functions for different scenarios
export function getOffersByGenre(genre: string): OfferWithBook[] {
  const allOffers = [...mockOffers, ...mockRomanticOffers];
  return allOffers.filter((offer) =>
    offer.book.genres.some(
      (bookGenre) => bookGenre.toLowerCase() === genre.toLowerCase()
    )
  );
}

export function getOffersBySearch(query: string): OfferWithBook[] {
  const lowerQuery = query.toLowerCase();

  // Special case for "recommended" - return a curated selection
  if (lowerQuery === 'recommended') {
    // Return a mix of popular books (first few from each category)
    return [...mockOffers.slice(0, 3), ...mockRomanticOffers.slice(0, 2)];
  }

  return [...mockOffers, ...mockRomanticOffers].filter(
    (offer) =>
      offer.book.title.toLowerCase().includes(lowerQuery) ||
      offer.book.authors.some((author) =>
        author.toLowerCase().includes(lowerQuery)
      ) ||
      offer.book.genres.some((genre) =>
        genre.toLowerCase().includes(lowerQuery)
      )
  );
}

export function getOffersByCondition(
  offers: OfferWithBook[],
  condition: 'new' | 'used'
): OfferWithBook[] {
  return offers.filter(
    (offer) => offer.book.condition.toLowerCase() === condition
  );
}

// Get offer by ID
export function getOfferWithBookById(
  id: number | string
): OfferWithBook | null {
  const offerId: number = typeof id === 'string' ? parseInt(id, 10) : id;
  const allOffers = [...mockOffers, ...mockRomanticOffers];
  return allOffers.find((offer) => parseInt(offer.id, 10) === offerId) || null;
}

// Sort offers
export function sortOffers(
  offers: OfferWithBook[],
  sortBy: string
): OfferWithBook[] {
  const sorted = [...offers];

  switch (sortBy) {
    case 'price-low':
      return sorted.sort((a, b) => a.price - b.price);
    case 'price-high':
      return sorted.sort((a, b) => b.price - a.price);
    case 'newest':
      return sorted.sort((a, b) => {
        const aId = parseInt(a.id, 10);
        const bId = parseInt(b.id, 10);
        return bId - aId;
      });
    case 'oldest':
      return sorted.sort((a, b) => {
        const aId = parseInt(a.id, 10);
        const bId = parseInt(b.id, 10);
        return aId - bId;
      });
    case 'title':
      return sorted.sort((a, b) => a.book.title.localeCompare(b.book.title));
    default:
      return sorted;
  }
}

// Apply all filters and sorting
export function applyFiltersAndSort(filters: {
  exchange?: boolean;
  condition?: 'new' | 'used';
  categories?: string[];
  sort?: string;
  query?: string;
  genre?: string;
}): OfferWithBook[] {
  let offers = [...mockOffers, ...mockRomanticOffers];

  // Filter by search query
  if (filters.query) {
    offers = getOffersBySearch(filters.query);
  }

  // Filter by genre (from genre pages)
  if (filters.genre) {
    offers = getOffersByGenre(filters.genre);
  }

  // Filter by exchange availability
  if (filters.exchange !== undefined) {
    offers = offers.filter((offer) =>
      filters.exchange
        ? offer.type === 'EXCHANGE' || offer.type === 'SELL_EXCHANGE'
        : offer.type === 'SELL'
    );
  }

  // Filter by condition
  if (filters.condition) {
    offers = getOffersByCondition(offers, filters.condition);
  }

  // Filter by categories/genres
  if (filters.categories && filters.categories.length > 0) {
    offers = offers.filter((offer) =>
      offer.book.genres.some((genre) =>
        filters.categories!.some(
          (category) => genre.toLowerCase() === category.toLowerCase()
        )
      )
    );
  }

  // Apply sorting
  if (filters.sort) {
    offers = sortOffers(offers, filters.sort);
  }

  return offers;
}

// Get seller by ID
export function getSellerById(
  sellerId: number | string
): (typeof mockSellers)[0] | null {
  return mockSellers.find((seller) => seller.id === sellerId) || null;
}

// Create mock response for single offer
export function createMockOfferResponse(
  offer: OfferWithBook | null
): OfferWithBook | null {
  return offer;
}
